# Desafio Fullstack

## Rodar
cd backend-module
mvn spring-boot:run

## Endpoints
GET /api/v1/beneficios  
POST /api/v1/beneficios  
POST /api/v1/beneficios/transfer  

## Banco
Scripts em db/
