package com.example.backend.service;

import com.example.backend.entity.Beneficio;
import com.example.backend.repository.BeneficioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class BeneficioService {

    private final BeneficioRepository repo;

    public BeneficioService(BeneficioRepository repo) {
        this.repo = repo;
    }

    public List<Beneficio> listar() {
        return repo.findAll();
    }

    public Beneficio criar(Beneficio b) {
        return repo.save(b);
    }

    public void deletar(Long id) {
        repo.deleteById(id);
    }

    @Transactional
    public void transfer(Long fromId, Long toId, BigDecimal amount) {

        if (fromId.equals(toId)) {
            throw new RuntimeException("IDs iguais");
        }

        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Valor inválido");
        }

        Beneficio from = repo.findById(fromId)
                .orElseThrow(() -> new RuntimeException("Origem não encontrada"));

        Beneficio to = repo.findById(toId)
                .orElseThrow(() -> new RuntimeException("Destino não encontrado"));

        if (from.getValor().compareTo(amount) < 0) {
            throw new RuntimeException("Saldo insuficiente");
        }

        from.setValor(from.getValor().subtract(amount));
        to.setValor(to.getValor().add(amount));

        repo.save(from);
        repo.save(to);
    }
}