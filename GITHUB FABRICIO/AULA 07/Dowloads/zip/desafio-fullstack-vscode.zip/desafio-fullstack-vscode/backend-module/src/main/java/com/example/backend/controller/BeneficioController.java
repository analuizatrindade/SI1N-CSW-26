package com.example.backend.controller;

import com.example.backend.entity.Beneficio;
import com.example.backend.service.BeneficioService;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/beneficios")
public class BeneficioController {

    private final BeneficioService service;

    public BeneficioController(BeneficioService service) {
        this.service = service;
    }

    @GetMapping
    public List<Beneficio> listar() {
        return service.listar();
    }

    @PostMapping
    public Beneficio criar(@RequestBody Beneficio b) {
        return service.criar(b);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        service.deletar(id);
    }

    @PostMapping("/transfer")
    public void transfer(
        @RequestParam Long fromId,
        @RequestParam Long toId,
        @RequestParam BigDecimal amount
    ) {
        service.transfer(fromId, toId, amount);
    }
}